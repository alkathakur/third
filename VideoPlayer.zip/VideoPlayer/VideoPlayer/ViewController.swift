//
//  ViewController.swift
//  VideoPlayer
//
//  Created by Satyam Kumar on 19/02/19.
//  Copyright © 2019 Satyam Kumar. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class ViewController: UIViewController {
    
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let path = Bundle.main.path(forResource: "videoplayback", ofType: "mp4") else { return}
        
        let videoURL = URL(fileURLWithPath: path)
        let player = AVPlayer(url: videoURL)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        self.present (playerViewController, animated:  true ){
            playerViewController.player?.play()
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

//    @IBAction func videoPlay(_ sender: Any) {
//        
//        
//        let vedioUrl = "https://www.youtube.com/watch?v=pNyVfBPrXWM"
//        
//        let player = AVPlayer(url: URL(fileURLWithPath:vedioUrl))
//        let playerController = AVPlayerViewController()
//        playerController.player = player
//        present(playerController, animated:  true){
//            player.play()
//        }
//    }
    
}

